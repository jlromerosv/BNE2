/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'pt-br', {
	copy: 'Copyright &copy; $1. Todos os direitos reservados.',
	dlgTitle: 'Sobre o CKEditor 4',
	moreInfo: 'Para informações sobre a licença por favor visite o nosso site:'
} );
