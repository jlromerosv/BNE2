/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'sr-latn', {
	copy: 'Copyright &copy; $1. Sva prava zadržana.',
	dlgTitle: 'O CKEditor 4',
	moreInfo: 'Za informacije o licenci posetite našu web stranicu:'
} );
